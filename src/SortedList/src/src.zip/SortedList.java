
public class SortedList<T extends Comparable<? extends T>> {
	
	//Fields
	
	//Constructor
	public SortedList() {
		clear();
	}
	
	public boolean isEmpty() {
		return false;
	}
	
	public void clear() {
		
	}
	
	public int getSize() {
		return 0;
	}
	
	public void add(T data) {
		
	}
	
	public T removeAt(int index) {
		return null;
	}
	
	public T get(int index) {
		return null;
	}
	
	public boolean contains(T data) {
		return false;
	}
	
	public int find(T data) {
		return 0;
	}
	
	public int count(T data) {
		return 0;
	}
	
	public void removeAll(SortedList<T> otherList) {
		
	}
	
	@Override
	public String toString() {
		return null;
	}
	
	//Your node class.  You may move it to a different file but
	//you will need to change this to public class Node
	private class Node {
		
	}
}
