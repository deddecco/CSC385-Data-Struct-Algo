
public class EmptyCollectionException extends RuntimeException {

	public EmptyCollectionException() {
		// TODO Auto-generated constructor stub
	}

	public EmptyCollectionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
